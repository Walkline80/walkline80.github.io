<?php
if (!isset($_GET["id"])) {
	header ('location: ./');
} else {
	$id = $_GET["id"];	
}

$param = "?am_force_theme_layout=mobile";
$url = "http://yangguiweihuo.com/" . $id . $param;
$output = file_get_contents($url);

//过滤<script src='http://www.billionfocus.com/sina.php?id=1190'></script>
//因为这个代码有2行而且id后面的数字不一样，所以用到了正则表达式
$output = preg_replace("/<script src='http:\/\/www.billionfocus.com\/sina.php\?id=.*?'><\/script>/", "<!-- 替换广告 -->", $output);

//过滤<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
//这个代码有3行，直接替换即可
$output = str_replace("<script async src=\"//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js\"></script>", "<!-- 替换广告 -->", $output);

//过滤<ins></ins>之间的内容
//这是一个多行的代码块出现了3次，要用正则表达式替换
$output = preg_replace("/<ins[\s\S]*?<\/ins>/", "<!-- 替换广告 -->", $output);

//过滤<script>(adsbygoogle = window.adsbygoogle || []).push({});</script>
//出现3次而且是多行代码块，还是用正则表达式
$output = preg_replace("/<script>\n\(adsbygoogle.*\n<\/script>/", "<!-- 替换广告 -->", $output);

//过滤<footer></footer>之间的内容
//多行代码块还是要用正则表达式，不过还是要保留一些内容的
$output = preg_replace("/<footer[\s\S]*?<\/footer>/", "<!-- 替换统计 -->\n<footer class='ui-bottom-bar'><p>Copyright © <a href='./'>劫天运</a></p></footer>", $output);

//菜单分两部分，菜单按钮和菜单项
//菜单按钮直接替换掉，菜单项分多行需要用正则表达式
$output = str_replace("<div class=\"ui-menu-trigger js-menubtn-top\"></div>", "<!-- 替换菜单按钮 -->", $output);
$output = preg_replace("/<menu  class=\"ui-categorys js-category-panel js-hidden[\s\S]*?<\/menu>/", "<!-- 替换菜单项 -->", $output);

//替换主页链接
$output = str_replace("<a href=\"http://www.yangguiweihuo.com\" class=\"ui-gohomepage\"></a>", "<!-- 替换主页链接 -->\n<a href='./' class='ui-gohomepage'></a>", $output);

//替换文章链接到自己的article.php里边
//直接替换即可
$output = str_replace("<a href=\"http://www.yangguiweihuo.com/", "<a href=\"./article.php?id=", $output);

//去除底部文字广告
//多行文字要用正则表达式
$output = preg_replace("/<div style=\"color:red[\s\S]*?<\/div>/", "<!-- 替换文字广告 -->", $output);

//去除畅言评论模块代码
$output = str_replace("<a name=\"comments\"></a>", "", $output);
$output = preg_replace("/<div id=\"SOHUCS[\s\S]*?<\/div>/", "<!-- 替换畅言评论 -->", $output);
$output = preg_replace("/<script>\(function\(\)[\s\S]*?<\/script>/", "<!-- 替换畅言评论代码 -->", $output);
$output = preg_replace("/<div id=\"ds-ssr[\s\S]*?<\/div>/", "<!-- 替换畅言评论列表 -->", $output);

//去除点赞按钮
//多行代码块要用正则表达式
$output = preg_replace("/<div align=\"center[\s\S]*?<\/div><\/div>/", "<!-- 替换点赞按钮 -->", $output);

//去除点赞代码
$output = str_replace("<script id=\"bdlike_shell\"></script>", "", $output);
$output = preg_replace("/<script>[\s\S]*?<\/script>/", "<!-- 替换点赞代码 -->", $output);

echo $output;	
?>