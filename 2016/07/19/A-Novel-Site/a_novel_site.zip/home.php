<?php
if (!isset($_GET["page"])) {
	$page = "";
} else {
	$page = "page/" . $_GET["page"];	
}

$param = "?am_force_theme_layout=mobile";
$url = "http://www.yangguiweihuo.com/" .$page . $param;

$output = file_get_contents($url);

//过滤<script src='http://www.billionfocus.com/sina.php?id=1190'></script>
//因为这个代码有2行而且id后面的数字不一样，所以用到了正则表达式
$output = preg_replace("/<script src='http:\/\/www.billionfocus.com\/sina.php\?id=.*?'><\/script>/", "<!-- 替换广告 -->", $output);

//过滤<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
//这个代码有3行，直接替换即可
$output = str_replace("<script async src=\"//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js\"></script>", "<!-- 替换广告 -->", $output);

//过滤<ins></ins>之间的内容
//这是一个多行的代码块出现了3次，要用正则表达式替换
$output = preg_replace("/<ins[\s\S]*?<\/ins>/", "<!-- 替换广告 -->", $output);

//过滤<script>(adsbygoogle = window.adsbygoogle || []).push({});</script>
//出现3次而且是多行代码块，还是用正则表达式
$output = preg_replace("/<script>\n\(adsbygoogle.*\n<\/script>/", "<!-- 替换广告 -->", $output);

//过滤<footer></footer>之间的内容
//多行代码块还是要用正则表达式，不过还是要保留一些内容的
$output = preg_replace("/<footer[\s\S]*?<\/footer>/", "<!-- 替换统计 -->\n<footer class='ui-bottom-bar'><p>Copyright © <a href='./'>劫天运</a></p></footer>", $output);

//菜单分两部分，菜单按钮和菜单项
//菜单按钮直接替换掉，菜单项分多行需要用正则表达式
$output = str_replace("<div class=\"ui-menu-trigger js-menubtn-top\"></div>", "<!-- 替换菜单按钮 -->", $output);
$output = preg_replace("/<div  class=\"ui-cateandsearch js-category-search[\s\S]*?<\/div><br \/>/", "<!-- 替换菜单项 -->", $output);

//替换主页链接
$output = str_replace("<a href=\"http://www.yangguiweihuo.com\" class=\"ui-gohomepage\"></a>", "<!-- 替换主页链接 -->\n<a href='./' class='ui-gohomepage'></a>", $output);

//替换翻页链接为本页面，用到正则表达式
$output = preg_replace("/http:\/\/www.yangguiweihuo.com\/page\//", "./home.php?page=", $output);
//去掉多余的参数
$output = str_replace("?am_force_theme_layout=mobile", "", $output);
//替换上一页和第一页链接
$output = str_replace("<a href='http://www.yangguiweihuo.com/' class=", "<a href='./' class=", $output);

//替换文章链接到自己的article.php里边
//直接替换即可
$output = str_replace("<a href=\"http://www.yangguiweihuo.com/", "<a href=\"./article.php?id=", $output);

echo $output;	
?>